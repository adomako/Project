package main;

public class Game {

	private static Panel panel;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		panel = new Panel();
	}

}
