package main;

public class Fitness {
	private int entropy;
	
	public int calculate(Panel panel) {
		
		return entropy;
	}
}
