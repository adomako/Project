package main;


import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public class Panel {
	private Collection<Block> blocks  = new HashSet();
	private int entropy;
	private int winFlag;
	private Fitness fitness;
	/**
	 * This is constructor for panel
	 */
	public Panel() {}
	
	
	/**
	 * This function is used for change the location for 2 blocks
	 */
	public void swap(Block blockA, Block blockB) {
		 Block temp;
		 temp = blockA;
		 blockA = blockB;
		 blockB = temp;
		 
		 winFlag = fitness.calculate(this);
	}
	
	public int getEntropy() {
		return entropy;
	}


	public void setEntropy(int entropy) {
		this.entropy = entropy;
	}


	/**
	 * this function is used for checking if puzzle is solved
	 * @return true solvoed, false not
	 * 
	 */
	public boolean winOrNot() {
		if(this.winFlag == 0)
			return true;
		else
			return false;
	}
}
